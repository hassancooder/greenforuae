<script>
    const rootURL = "<?= ROOT_URL; ?>".slice(0, -1);
    const apiSlug = "<?= API_SLUG; ?>";
</script>
<script src="<?= getAsset('jquery.min.js', 'js/'); ?>"></script>
<script src="<?= getAsset('aos.js', 'js/'); ?>"></script>
<script src="<?= getAsset('alpinejs.min.js', 'js/'); ?>"></script>
<script src="<?= getAsset('swiper-bundle.min.js', 'js/'); ?>"></script>
<script src="<?= getAsset("custom.js", 'js/'); ?>"></script>